from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import os
import numpy as np
from sklearn.preprocessing import LabelEncoder
from sklearn.svm import SVC
import pickle
from pydub import AudioSegment
import speech_recognition as sr

app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = 'static/uploads'

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Fake database: przechowuje użytkowników (klucz to login)
users_db = {}
voice_models = {}

# Klasa User
class User(UserMixin):
    def __init__(self, id, username):
        self.id = id
        self.username = username

# Funkcja ładująca użytkownika na podstawie ID
@login_manager.user_loader
def load_user(user_id):
    return users_db.get(user_id)

def extract_features_from_microphone():
    """Przechwytuje dźwięk z mikrofonu i ekstraktuje cechy."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Nagrywanie: proszę mówić przez kilka sekund...")
        audio = recognizer.listen(source)
    try:
        features = recognizer.recognize_google(audio)
        return features
    except sr.UnknownValueError:
        return None

@app.route('/')
@login_required
def home():
    return f'Witaj, {current_user.username}! <br><a href="{url_for("logout")}">Wyloguj</a>'

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        if username in [user.username for user in users_db.values()]:
            flash('Użytkownik już istnieje.')
            return redirect(url_for('register'))

        features = extract_features_from_microphone()
        if features is None:
            flash('Nie udało się przetworzyć głosu. Spróbuj ponownie.')
            return redirect(url_for('register'))

        user_id = str(len(users_db) + 1)
        new_user = User(user_id, username)
        users_db[user_id] = new_user

        if username not in voice_models:
            voice_models[username] = []
        voice_models[username].append(features)

        flash('Zarejestrowano pomyślnie!')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')

        user = next((u for u in users_db.values() if u.username == username), None)
        if not user:
            flash('Użytkownik nie istnieje.')
            return redirect(url_for('login'))

        features = extract_features_from_microphone()
        if features is None:
            flash('Nie udało się przetworzyć głosu.')
            return redirect(url_for('login'))

        known_features = voice_models.get(username, [])

        if features in known_features:
            login_user(user)
            flash('Zalogowano pomyślnie!')
            return redirect(url_for('home'))
        else:
            flash('Weryfikacja głosu nieudana.')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Wylogowano pomyślnie!')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)